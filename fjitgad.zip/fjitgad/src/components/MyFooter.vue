<template>
    <footer class="footer py-3 bg-dark">
      <div class="container">
          <div class="row text-center">
              <!-- dos cuadro azul y plomo para separar h1 y h4-->
              <span class="divider grey"></span>
              <h6>© <span id="year01"></span>. Universidad Técnica Estatal de Quevedo derechos reservados.</h6>                  
              <h6>Quevedo - Los Ríos - Ecuador</h6>  
              <h6>www.uteq.edu.ec</h6>  
          </div>
      </div>
  </footer>
</template>

<script>
export default {
    name: "MyFooter",
    setup() {
        
    },
}
</script>