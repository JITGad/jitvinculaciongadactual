<template>
  <div class="row">
    <div class="row">
      <div class="col">
        <div class="mx-auto w-75 px-5 text-white text-center">
          <img src="../assets/image/spinner.gif" width="400" class="img-fluid" />
          <br />
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "Loading",
};
</script>