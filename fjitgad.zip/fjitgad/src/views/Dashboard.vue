<template>
    <main-layout-admin>
        Inicio
    </main-layout-admin>
</template>

<script>
export default {
    name: "Dashboard"
}
</script>