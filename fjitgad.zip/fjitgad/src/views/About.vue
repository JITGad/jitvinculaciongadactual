<template>
  <main-layout-juego :backgroundBlanc="true">
    <main>
      <section class="py-5 text-center container">
        <div class="row py-lg-5">
          <div class="col-lg-6 col-md-8 mx-auto">
            <h1 class="fw-light">JIT</h1>
            <h1 class="fw-light">Juegos interactivos para todos</h1>
            <p class="lead text-muted">
              Tecnologías de la Información y Comunicación enfocadas a la discapacidad en la zona de influencia de la UTEQ. Programa de vinculación con la sociedad. Carrera de Ingeniería en Software/Sistemas/Telemática. Facultad de Ciencias de la Ingeniería. Universidad Técnica Estatal de Quevedo. 
            </p>
          </div>
        </div>
      </section>
      <div class="album py-5 bg-light">
        <div class="container">
          <h1 class="fw-light text-center">Autores</h1>
          <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
            <div class="col">
              <div class="card shadow-sm h-100">
                <img
                  src="../assets/image/jose.jpeg"
                  class="card-img-top"
                  alt="..."
                />
                <div class="card-body">
                  <p class="card-title">Garcia Lopez Jose Gerardo</p>
                </div>
                <div class="card-footer">
                  <a
                    class="px-2 text-truncate"
                    href="https://www.facebook.com/jgarcia1924/"
                    target="_blank"
                    ><i class="fab fa-facebook"></i>facebook</a
                  >
                  <a
                    class="px-2 text-truncate"
                    href="https://mail.google.com/"
                    target="_blank"
                    ><i class="fas fa-envelope"></i>
                    jgarcia24121996@gmail.com</a
                  >
                  <a
                    class="px-2 text-truncate"
                    href="https://www.whatsapp.com/?lang=es"
                    target="_blank"
                    ><i class="fab fa-whatsapp"></i>0995040419</a
                  >
                </div>
              </div>
            </div>
            <div class="col">
              <div class="card shadow-sm h-100">
                <img
                  src="../assets/image/aura2.jpg"
                  class="card-img-top"
                  alt="..."
                />
                <div class="card-body">
                  <p class="card-text">Aura Oliva Taquez Suares</p>
                </div>
                <div class="card-footer">
                  <a
                    class="px-2 text-truncate"
                    href="https://www.facebook.com/VaneAzuliita"
                    target="_blank"
                    ><i class="fab fa-facebook"></i>facebook</a
                  >
                  <a
                    class="px-2 text-truncate"
                    href="https://outlook.live.com/"
                    target="_blank"
                    ><i class="fas fa-envelope"></i>auri291@hotmail.com</a
                  >
                  <a
                    class="px-2 text-truncate"
                    href="https://www.whatsapp.com/?lang=es"
                    target="_blank"
                    ><i class="fab fa-whatsapp"></i>0968890840</a
                  >
                </div>
              </div>
            </div>
            <div class="col">
              <div class="card shadow-sm h-100">
                <img
                  src="../assets/image/molina.jpeg"
                  class="card-img-top"
                  alt="..."
                />
                <div class="card-body">
                  <p class="card-text">Jorge Farouk Molina Noboa</p>
                </div>
                <div class="card-footer">
                  <a
                    class="px-2 text-truncate"
                    href="https://www.facebook.com/jorgefarut.molinanoboa"
                    target="_blank"
                    ><i class="fab fa-facebook"></i>facebook</a
                  >
                  <a
                    class="px-2 text-truncate"
                    href="https://outlook.live.com/"
                    target="_blank"
                    ><i class="fas fa-envelope"></i
                    >jorge-molina12@hotmail.com</a
                  >
                  <a
                    class="px-2 text-truncate"
                    href="https://www.whatsapp.com/?lang=es"
                    target="_blank"
                    ><i class="fab fa-whatsapp"></i>0967939471</a
                  >
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
  </main-layout-juego>
</template>

<style>
.bd-placeholder-img {
  font-size: 1.125rem;
  text-anchor: middle;
  -webkit-user-select: none;
  -moz-user-select: none;
  user-select: none;
}

@media (min-width: 768px) {
  .bd-placeholder-img-lg {
    font-size: 3.5rem;
  }
}
</style>