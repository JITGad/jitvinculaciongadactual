export default class Route {

    route = "";
    label = "";

    constructor(_route = "", _label = "") {
        this.route = _route;
        this.label = _label;
    }
}