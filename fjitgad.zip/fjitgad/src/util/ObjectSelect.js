export default class ObjectSelect {

    id = "";
    text = "";
    value = "";

    constructor(_id = "", _text = "", _value = "") {
        this.id = _id;
        this.text = _text;
        this.value = _value;
    }
}