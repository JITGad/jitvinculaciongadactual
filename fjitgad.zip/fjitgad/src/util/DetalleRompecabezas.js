export default class DetalleRompecabezas {

    colorid = "";
    imagen = "";

    constructor(_colorid = "", _imagen = "") {
        this.colorid = _colorid;
        this.imagen = _imagen;
    }
}